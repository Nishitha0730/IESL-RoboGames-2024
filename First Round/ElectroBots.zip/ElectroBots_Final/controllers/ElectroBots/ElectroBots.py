import cv2
import numpy as np
import math



directions=[(-1,0),(0,1),(1,0),(0,-1)]    #North, East, South, West

from controller import Robot,Camera, Compass
from collections import deque
from math import floor

maze_size = 10

m = [[255] * maze_size for _ in range(maze_size)]   #Initialize the maze, m =maze

goal=[[3,7],[9,5],[6,7],[5,8],[6,0]]  

# m[goal[0]][goal[1]] = 0 
m[goal[0][0]][goal[0][1]] = 0

goal_number = 0  

direc = [[-1, 0], [0, 1], [1, 0], [0, -1]]    #North, East, South, West

cells = [[[0 for _ in range(4)] for _ in range(maze_size)] for _ in range(maze_size)]
  # for map the walls in the maze
 


speed = 6  # best value - 6.28 
i=0 # use for starting position & direction calibration
theeta_z = 0  # use for precise left,right turn

colors=["Red","Yellow","Pink","Brown","Green"]

color_ranges = {
    "Red": ((0, 50), (0, 50), (0, 100)),
    "Yellow": ((0, 50), (200, 255), (200, 255)),
    "Pink": ((200, 255), (0, 50), (200, 255)),
    "Brown": ((0, 80), (90, 120), (100, 200)),
    "Green": ((0, 50), (200, 255), (0, 50)),
}


if __name__ == "__main__":
    robot = Robot()
    TIME_STEP = 8

    
    left_motor = robot.getDevice("left wheel motor")
    right_motor = robot.getDevice("right wheel motor")
    
    camera = robot.getDevice('camera')  
    camera.enable(TIME_STEP)
    
    width = camera.getWidth()
    height = camera.getHeight()
    
    gps = robot.getDevice('gps');
    gps.enable(TIME_STEP);

    left_motor.setPosition(float("inf"))
    right_motor.setPosition(float("inf"))
    left_motor.setVelocity(0.0)
    right_motor.setVelocity(0.0)
    
    left_motor_sensor = left_motor.getPositionSensor()
    right_motor_sensor = right_motor.getPositionSensor()
    left_motor_sensor.enable(TIME_STEP)
    right_motor_sensor.enable(TIME_STEP)
    
    compass = robot.getDevice('compass')
    compass.enable(TIME_STEP)
    
    gyro = robot.getDevice("gyro1")
    gyro.enable(TIME_STEP)



    proximity_sensors = []
    sensor_names = ["ps7", "ps2", "ps4", "ps5",]  # Front, Right, Back , left
    for name in sensor_names:
        sensor = robot.getDevice(name)
        sensor.enable(TIME_STEP)
        proximity_sensors.append(sensor)
       
    # robot_position = [gps_to_cell_coordinates(gps)]
    # print(robot_position)
    
    
    def detect_color(average_color):
        r, g, b = average_color
        for color_name, ((r_min, r_max), (g_min, g_max), (b_min, b_max)) in color_ranges.items():
            if r_min <= r <= r_max and g_min <= g <= g_max and b_min <= b <= b_max:
                return color_name
        return "Unknown"
        
        
    def get_starting_pos(gps):
        
        
        
        gps_x = gps[0]
        gps_y = gps[1]
    
        maze_size = 10  
        square_size = 0.25  
        origin_offset = (maze_size / 2) * square_size 
        # Calculate row and column
        row = floor((origin_offset - gps_y) / square_size)
        col = floor((gps_x + origin_offset) / square_size)
    
        return row, col
        # gps_values = gps.getValues()
        # print(gps_values)
        # robot_position = [gps_to_cell_coordinates(gps_values)]
        # print(robot_position)

    def floodfill(x, y):
        q = deque()
        q.append((x, y))
    
        while q:
            cx, cy = q.popleft()
            for dx, dy in direc:
                nx, ny = cx + dx, cy + dy
                if 0 <= nx <= (maze_size-1) and 0 <= ny <= (maze_size-1) and m[nx][ny] == 255:
                    m[nx][ny] = m[cx][cy] + 1
                    q.append((nx, ny))
                    
       
    def floodfill_again(x, y):
        global m
        m = [[255] * maze_size for _ in range(maze_size)]  
        m[goal[goal_number][0]][goal[goal_number][1]] = 0  
    
        queue = deque([(goal[goal_number][0], goal[goal_number][1])])  
    
        while queue:
            cx, cy = queue.popleft()
    
            for i, (dx, dy) in enumerate(direc):
                nx, ny = cx + dx, cy + dy
    
                if 0 <= nx < maze_size and 0 <= ny < maze_size:
                  
                    if cells[cx][cy][i] == 1:
                        continue
    
                   
                    if m[nx][ny] == 255:
                        m[nx][ny] = m[cx][cy] + 1
                        queue.append((nx, ny))         
                        
        
    def wall_mapping(x, y):
        global cells
        global robot_direction
        max_x, max_y = len(cells) - 1, len(cells[0]) - 1 
    
        if robot_direction == 0:  # North
            if proximity_sensors[0].getValue() > 1000:  # Front
                cells[x][y][0] = 1  
                if x > 0:
                    cells[x-1][y][2] = 1  
            if proximity_sensors[1].getValue() > 1000:  # Right
                cells[x][y][1] = 1  # East wall
                if y < max_y:
                    cells[x][y+1][3] = 1  
            if proximity_sensors[2].getValue() > 1000:  # Back
                cells[x][y][2] = 1  # South wall
                if x < max_x:
                    cells[x+1][y][0] = 1 
            if proximity_sensors[3].getValue() > 1000:  # Left
                cells[x][y][3] = 1  # West wall
                if y > 0:
                    cells[x][y-1][1] = 1  
    
        elif robot_direction == 1:  # East
            if proximity_sensors[0].getValue() > 1000:  # Front
                cells[x][y][1] = 1  # East wall
                if y < max_y:
                    cells[x][y+1][3] = 1 
            if proximity_sensors[1].getValue() > 1000:  # Right
                cells[x][y][2] = 1  # South wall
                if x < max_x:
                    cells[x+1][y][0] = 1  
            if proximity_sensors[2].getValue() > 1000:  # Back
                cells[x][y][3] = 1  # West wall
                if y > 0:
                    cells[x][y-1][1] = 1  
            if proximity_sensors[3].getValue() > 1000:  # Left
                cells[x][y][0] = 1  # North wall
                if x > 0:
                    cells[x-1][y][2] = 1  
    
        elif robot_direction == 2:  # South
            if proximity_sensors[0].getValue() > 1000:  # Front
                cells[x][y][2] = 1  # South wall
                if x < max_x:
                    cells[x+1][y][0] = 1 
            if proximity_sensors[1].getValue() > 1000:  # Right
                cells[x][y][3] = 1  # West wall
                # print("hi_2")
                if y > 0:
                    cells[x][y-1][1] = 1 
            if proximity_sensors[2].getValue() > 1000:  # Back
                cells[x][y][0] = 1  # North wall
                if x > 0:
                    cells[x-1][y][2] = 1  
            if proximity_sensors[3].getValue() > 1000:  # Left
                cells[x][y][1] = 1  # East wall
                if y < max_y:
                    cells[x][y+1][3] = 1
                      
    
        elif robot_direction == 3:  # West
            if proximity_sensors[0].getValue() > 1000:  # Front
                cells[x][y][3] = 1  # West wall
                if y > 0:
                    cells[x][y-1][1] = 1  
            if proximity_sensors[1].getValue() > 1000:  # Right
                cells[x][y][0] = 1  # North wall
                if x > 0:
                    cells[x-1][y][2] = 1 
            if proximity_sensors[2].getValue() > 1000:  # Back
                cells[x][y][1] = 1  # East wall
                if y < max_y:
                    cells[x][y+1][3] = 1  
            if proximity_sensors[3].getValue() > 1000:  # Left
                cells[x][y][2] = 1  # South wall
                if x < max_x:
                    cells[x+1][y][0] = 1  
           
                    
                
    
    def find_robot_direction(x,y):
        global robot_direction
        global robot_position
        motor_stop()
        if robot_direction == 0:
            if (x,y) == (-1,0): 
                robot_direction=0
                # while proximity_sensors[0].getValue() < 100:
                moveForward();
                robot_position[0]=robot_position[0]-1
            elif (x,y) == (0,1):
                robot_direction =1
                turnRight();
                robot_position[1]=robot_position[1]+1
            elif (x,y) == (1,0):
                robot_direction =2
                turnBack();
                robot_position[0]+=1
            elif (x,y) == (0,-1): 
                robot_direction =3
                turnLeft();
                robot_position[1]-=1
        elif robot_direction == 1:
            if (x,y) == (0,1):
                moveForward();
                robot_position[1]+=1
            elif (x,y) == (-1,0):
                turnLeft();   
                robot_direction=0
                robot_position[0]-=1    
            elif (x,y) == (1,0):
                turnRight();   
                robot_direction=2
                robot_position[0]+=1 
            elif (x,y) == (0,-1):
                turnBack();   
                robot_direction=3
                robot_position[1]-=1 
        elif robot_direction == 2:
            if (x,y) == (0,-1):
                turnRight()
                robot_direction=3
                robot_position[1]-=1 
            elif (x,y) == (1,0):
                moveForward()
                robot_position[0]+=1
            elif (x,y)==(0,1):
                turnLeft();
                robot_direction=1
                robot_position[1]+=1              
            elif (x,y)==(-1,0):
                turnBack();
                robot_direction = 0;
                robot_position[0]-=1 
        elif robot_direction == 3:
            if (x,y) == (-1,0):
                turnRight();
                robot_direction = 0
                robot_position[0]-=1 
            elif (x,y) == (1,0):
                turnLeft()
                robot_direction = 2
                robot_position[0]+=1
            elif (x,y) == (0,-1):
                moveForward();
                robot_position[1]-=1 
            elif (x,y) == (0,1):
                turnBack();
                robot_direction = 1;
                robot_position[1]+=1 

            
        # if ( robot_position[0] == goal[0]) and (robot_position[1]==goal[1]):
            # print("reached to the goal!!!")
            # motor_stop()
            # break
                     
                     
    def motor_stop():
        left_motor.setVelocity(0)
        right_motor.setVelocity(0)
        start_time = robot.getTime()
        while robot.getTime() - start_time < 0.5:
            robot.step(TIME_STEP)



     
     
    def turnRight():
        global theeta_z
        left_motor.setVelocity(0.45)  
        right_motor.setVelocity(-0.45)
        while (theeta_z > -1.565/4):
            robot.step(TIME_STEP)
            wx,wy,wz = gyro.getValues()[0] , gyro.getValues()[1] , gyro.getValues()[2]
            theeta_z += wz*TIME_STEP*0.001
            # print(theeta_z);        
        left_motor.setVelocity(0)
        right_motor.setVelocity(0) 
        theeta_z = 0 
        moveForward()
        

    def turnLeft():
        global theeta_z
        left_motor.setVelocity(-0.45)  
        right_motor.setVelocity(0.45)
        while (theeta_z < 1.565/4):
            robot.step(TIME_STEP)
            wx,wy,wz = gyro.getValues()[0] , gyro.getValues()[1] , gyro.getValues()[2]
            theeta_z += wz*TIME_STEP*0.001
            # print(theeta_z);
        left_motor.setVelocity(0)
        right_motor.setVelocity(0) 
        theeta_z = 0 
        moveForward()

    # def turnBack():
        # left_motor.setVelocity(-3)  
        # right_motor.setVelocity(3) 
           
        # turn_duration = 1.5
        # start_time = robot.getTime()
        # while robot.getTime() - start_time < turn_duration:
            # robot.step(TIME_STEP)
        # print("turn finiseh")
        # left_motor.setVelocity(0)
        # right_motor.setVelocity(0)            
        # moveForward()
        
    def turnBack():
        global theeta_z
        left_motor.setVelocity(-0.2)  
        right_motor.setVelocity(0.2)
        while (theeta_z < 3.14/4):
            robot.step(TIME_STEP)
            wx,wy,wz = gyro.getValues()[0] , gyro.getValues()[1] , gyro.getValues()[2]
            theeta_z += wz*TIME_STEP*0.001
            # print(theeta_z);
        left_motor.setVelocity(0)
        right_motor.setVelocity(0) 
        theeta_z = 0 
        moveForward()         
    
    
    def moveForward():
        distance = 0.25  
        wheel_velocity = speed 
        wheel_radius = 0.0205 
        
        # if (proximity_sensors[1].getValue()>3570):
            # left_motor.setVelocity(-speed)
            # right_motor.setVelocity(speed)
            # robot.step(TIME_STEP)
        # elif (proximity_sensors[1].getValue()<3550):
            # left_motor.setVelocity(speed)
            # right_motor.setVelocity(-speed)
            # robot.step(TIME_STEP)
        # if (proximity_sensors[3].getValue()>3335):
            # left_motor.setVelocity(speed)
            # right_motor.setVelocity(-speed)
            # robot.step(TIME_STEP) 
        # elif (proximity_sensors[3].getValue()<3320):
            # left_motor.setVelocity(-speed)
            # right_motor.setVelocity(speed)
            # robot.step(TIME_STEP)     
        
        forward_duration = distance / (wheel_velocity * wheel_radius)
        left_motor.setVelocity(wheel_velocity)
        right_motor.setVelocity(wheel_velocity)
        
        error_right = 3550- proximity_sensors[1].getValue()
        error_left = 3326 - proximity_sensors[3].getValue()
        
        # if 1000>error_right>-1000:
            # left_motor.setVelocity(speed*error_right*0.001)
            # right_motor.setVelocity(-speed*error_right*0.001)
            
        start_time = robot.getTime()
        
        while robot.getTime() - start_time < forward_duration:

            if proximity_sensors[0].getValue() > 2500: # Check there is wall infront of the robot
                print("Obstacle detected! Stopping.")
                motor_stop()
                return  

            
            robot.step(TIME_STEP)
            
       
        motor_stop()
        # print("first step done")
        
    def move_next_pos(x,y,robot_direction):
        for i, (dx, dy) in enumerate(direc):
            nx, ny = x + dx, y + dy
            if (0 <= nx < maze_size) and (0 <= ny < maze_size) and (m[nx][ny]<m[x][y]) :
                if cells[x][y][i] == 1:
                    continue
                else:
                    find_robot_direction(dx,dy)
                    break
                    
        
        
    def is_stuck(x, y):
        for i, (dx, dy) in enumerate(direc):
            nx, ny = x + dx, y + dy
            if (0 <= nx < maze_size) and (0 <= ny < maze_size):
                if cells[x][y][i] == 0 and m[nx][ny] < m[x][y]:
                    return False  # Not stuck
        return True  # Stuck    
        
    # def check_goal(x,y):
        # if robot_position[0] == goal[0] and robot_position[1] == goal[1]:
            # print("Reached the goal!")
            # motor_stop()
            # return True
               
        # return False  

    def check_goal(x,y):
        global m
        global goal_number
        if robot_position[0] == goal[goal_number][0] and robot_position[1] == goal[goal_number][1]:
            print("Reached the goal!")
            check_color();
            goal_number+=1
            if goal_number<5:
                m[goal[goal_number][0]][goal[goal_number][1]] = 0
                floodfill(goal[goal_number][0],goal[goal_number][1])
            # motor_stop()
            if robot_position[0] == goal[-1][0] and robot_position[1] == goal[-1][1]:
                motor_stop()
                return True
           
              
        return False  
    
    def check_color():
        left_motor.setVelocity(1)  
        right_motor.setVelocity(-1)         
        turn_duration = 10
        start_time = robot.getTime()
        while robot.getTime() - start_time < turn_duration:
            robot.step(TIME_STEP)
            if goal_color()==colors[goal_number]:
                print(f"reach goal: {goal_color()}")
                continue

        left_motor.setVelocity(0)
        right_motor.setVelocity(0) 
        
        left_motor.setVelocity(-1)  
        right_motor.setVelocity(1)         
        turn_duration = 10
        start_time = robot.getTime()
        while robot.getTime() - start_time < turn_duration:
            robot.step(TIME_STEP)

        left_motor.setVelocity(0)
        right_motor.setVelocity(0)       
    
    def get_starting_direction(compass_values):
        if round(compass_values[0])==1:return 0
        elif round(compass_values[1])==1:return 1
        elif round(compass_values[0])==-1:return 2
        elif round(compass_values[1])==-1:return 3    
    
    
    def goal_color():
        image = camera.getImage()
        width = camera.getWidth()
        height = camera.getHeight()
    
      
        image_array = np.frombuffer(image, dtype=np.uint8).reshape((height, width, 4))  # RGBA format
    
      
        center_region = image_array[height // 2 - 10:height // 2 + 10, width // 2 - 10:width // 2 + 10, :3]
        average_color = np.mean(center_region, axis=(0, 1))  # Compute average RGB values
        # print(average_color)
        # Detect the color
        detected_color = detect_color(average_color)
        # print(f"Detected Color: {detected_color}")
           
        return detected_color  
        
        
                    
         
    # floodfill(goal[0],goal[1])
    floodfill(goal[0][0],goal[0][1])
   
    while robot.step(TIME_STEP) != -1:
    
        if i==0:
            gps_values = gps.getValues()
            compass_values = compass.getValues()
            
            robot_position = list(get_starting_pos(gps_values))
            robot_direction = get_starting_direction(compass_values)
            
            i+=1
            
            print(robot_position)
            
        x,y = robot_position
        print(robot_position)
        print(robot_direction)
        print("Goal no is : " ,goal_number)
        
        # print(proximity_sensors[3].getValue())     
        
        # turnLeft()
            
        
        wall_mapping(x,y)
        print(cells)
        if check_goal(x,y)  :
            print(m) 
            break  
        if (is_stuck(x,y)):
            print("Robot is stuck. Recalculating path...")
            motor_stop()
            floodfill_again(goal[goal_number][0],goal[goal_number][1])
            print(m)
            

        
        move_next_pos(x,y,robot_direction)
        
